import {LightningElement, track} from 'lwc';
import getAirportName from '@salesforce/apex/AirportSearchClass.getAirportName';
import getAllAirportDetails from '@salesforce/apex/AirportSearchClass.getAllAirportDetails';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';
export default class AirportDetails extends LightningElement {

    @track iataCode 
    @track airportname
    @track userLocalTime
    @track localTimeAtAirport
    containsAirportName = false;
    containsIATACode = false;
    bothFieldsEntered = false;
    noFieldEntered = false;
    valueFound = false;
    errorValue
    
    handleIATAChange(event) {
        this.iataCode = event.target.value; }
    handleAirportNameChange(event) {
        this.airportname = event.target.value; }

    connectedCallback() {
        var dateValue = new Date().toLocaleTimeString();
        this.userLocalTime = dateValue; }
    
    handleSubmit(){
        //Checking if only IATA Code is entered
        if((this.iataCode != null && this.iataCode != '' && typeof this.iataCode != undefined) && (this.airportname == null || this.airportname == '' || typeof this.airportname == undefined)) {
                this.containsIATACode = true;
        }
        //Checking if only Airport name is entered
        else if((this.airportname != null && this.airportname != '' && typeof this.airportname != undefined) && (this.iataCode == null || this.iataCode == '' || typeof this.iataCode == undefined )) {
                this.containsAirportName = true;
        }
          //Checking if none of the values are entered
        else if((this.airportname == null || this.airportname == '' || typeof this.airportname == undefined) && (this.iataCode == null || this.iataCode == '' || typeof this.iataCode == undefined)) {
                this.noFieldEntered = true;
        }
        //Checking if both the values are entered
        else { this.bothFieldsEntered = true; }

        // Performing operations based on the input/inputs entered
        if(this.noFieldEntered) {
            this.showToast("Error!", "Please enter the input field to search", "error")
            this.noFieldEntered = false; 
        }
        if(this.bothFieldsEntered) {
            this.showToast("Error!", "Please enter only one input field to search", "error")
            this.bothFieldsEntered = false; 
        }

        if(this.containsAirportName) {
            getAllAirportDetails({})
                .then((response)=> {
                    var parsedData = JSON.parse(response);
                    for(let i = 0; i < parsedData.data.length; i++) {
                        let obj = parsedData.data[i];
                        if(obj.nameAirport == this.airportname) {
                            this.iataCode = obj.codeIataAirport;
                            var timezoneValue = obj.timezone;
                            this.localTimeAtAirport = new Date().toLocaleTimeString("en-US", { timeZone: timezoneValue });
                            this.valueFound = true;
                        }
                        this.containsAirportName = false;  
                    }
                    if(!this.valueFound) {
                    this.showToast("Error!", "Please enter a proper Airport name to search", "error")
                    }
                    this.valueFound = false;
                })
            .catch((error) => {
                this.errorValue = error;
                this.showToast("Error!", "Please check the input values", "error")
            });
        }

       if(this.containsIATACode) {
        getAirportName({searchCode : this.iataCode})
            .then((response)=> {
                var parsedData = JSON.parse(response);
                if(parsedData.success){
                this.airportname = parsedData.data[0].nameAirport;
                var timezoneValue = parsedData.data[0].timezone; 
                this.localTimeAtAirport = new Date().toLocaleTimeString("en-US", { timeZone: timezoneValue });
                this.containsIATACode = false;
                }
                else {
                this.showToast("Error!", "Please enter a proper IATA Code to search", "error")
                }
            })
            .catch((error) => {
                this.errorValue = error;
                this.showToast("Error!", "Please check the input values", "error")
            });
    
    }
            var dateValue = new Date().toLocaleTimeString();
            this.localTime = dateValue;
    }

    handleCancel() {
        this.airportname = '';
        this.iataCode = '';
        this.localTimeAtAirport = '';
    }

    showToast(title, message, variant) {
        const event = new ShowToastEvent({
            title,
            message,
            variant
    })
    this.dispatchEvent(event)
    }
}

   